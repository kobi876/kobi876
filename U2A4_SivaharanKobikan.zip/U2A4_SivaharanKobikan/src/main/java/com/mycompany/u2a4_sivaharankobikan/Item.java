/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.u2a4_sivaharankobikan;

/**
 *
 * @author kobikan
 */
public class Item {
   private String sku, name, cate;
    private int quant, mQuantity;
    private double vendorP, markupP, regularP, currentD, currentP;
    private static int fruitNum = 1, vegNum = 1, meatNum = 1;

    public Item(String sku, String name, String cate, int quant, int mQuantity,
            double vendorP, double markupP, double regularP,
            double currentD, double currentP) {
        this.sku = sku;
        this.name = name;
        this.cate = cate;
        this.quant = quant;
        this.mQuantity = mQuantity;
        this.vendorP = vendorP;
        this.markupP = markupP;
        this.regularP = regularP;
        this.currentD = currentD;
        this.currentP = currentP;
        switch (cate.toLowerCase()) {
            case "vegetable":
                this.sku = "VEG-" + vegNum++;
                break;
            case "meat":
                this.sku = "MEA-" + meatNum++;
                break;
            case "fruit":
                this.sku = "FRU-" + fruitNum++;
                break;
            default:
                break;
        }
    }

    public String getSku() {
        return sku;
    }

    public String getName() {
        return name;
    }

    public String getCate() {
        return cate;
    }

    public int getQuant() {
        return quant;
    }

    public int getMQuantity() {
        return mQuantity;
    }

    public double getVendorP() {
        return vendorP;
    }

    public double getMarkupP() {
        return markupP;
    }

    public double getRegularP() {
        return regularP;
    }

    public double getCurrentD() {
        return currentD;
    }

    public double getCurrentP() {
        return currentP;
    }

    public static int getFruitNum() {
        return fruitNum;
    }

    public static int getVegNum() {
        return vegNum;
    }

    public static int getMeatNum() {
        return meatNum;
    }

    @Override
    public String toString() {
        return sku + "," + name + "," + cate + "," + quant + "," + mQuantity + "," + String.format("%.2f", vendorP) + ","
        + String.format("%.2f", markupP) + "," + String.format("%.2f", regularP) + "," + String.format("%.2f", currentD) + ","
        + String.format("%.2f", currentP);
    } 
}
