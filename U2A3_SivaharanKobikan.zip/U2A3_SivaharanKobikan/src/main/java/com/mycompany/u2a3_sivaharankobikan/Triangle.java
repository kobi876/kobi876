/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.u2a3_sivaharankobikan;

/**
 *
 * @author kobikan
 */
public class Triangle extends Shape{
    private double base, height;
    private int ID;

    public Triangle(double base, double height, int ID) {
        this.base = base;
        this.height = height;
        this.ID = ID;
    }

    public double getArea() {
        return (base * height) / 2;
    }

    public int getID() {
        return ID;
    }

    public String toString() {
        return ID + " Triangle: Base = " + base + ", Height = " + height;
    }
    
     @Override
    public void setID(int ID) {
        this.ID = ID;
    }
}
