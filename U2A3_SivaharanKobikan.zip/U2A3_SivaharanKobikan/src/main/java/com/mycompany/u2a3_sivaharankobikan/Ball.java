/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.u2a3_sivaharankobikan;

/**
 *
 * @author kobikan
 */
public class Ball extends Shape{
    private double rad;
    private int ID;

    public Ball(double rad, int ID) {
        this.rad = rad;
        this.ID = ID;
    }

    public double getArea() {
        return Math.PI * (4* rad * rad);
    }

    public int getID() {
        return ID;
    }

    @Override
    public String toString() {
        return ID+"Ball: radius =" + rad;
    }
    
    @Override
    public void setID (int ID){
        this.ID = ID;
    }
}
