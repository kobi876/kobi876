/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.u2a3_sivaharankobikan;

/**
 *
 * @author kobikan
 */
public class Rectangle extends Shape{
    private double width, length;
    private int ID;

    public Rectangle(double width, double length, int ID) {
        this.width = width;
        this.length = length;
        this.ID = ID;
    }

    public double getArea() {
        return width * length;
    }

    public int getID() {
        return ID;
    }

    public String toString() {
        return ID + " Rectangle: Width " + width + ", Length = " + length;
    }
    
     @Override
    public void setID(int ID) {
        this.ID = ID;
    }
    
}
