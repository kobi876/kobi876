/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.u2a3_sivaharankobikan;

/**
 *
 * @author kobikan
 */
public class Trapezoid extends Shape{
    private double sWidth, lWidth, height;
    private int ID;

    public Trapezoid(double sWidth, double lWidth, double height, int ID) {
        this.sWidth = sWidth;
        this.lWidth = lWidth;
        this.height = height;
        this.ID = ID;
    }

    public double getArea() {
        return (sWidth + lWidth) / 2 * height;
    }

    public int getID() {
        return ID;
    }
    
    public String toString() {
        return ID + " Trapezoid: Smaller Width = " + sWidth + ", Larger Width = " + lWidth + ", Height = " + height;
    }
    
     @Override
    public void setID(int ID) {
        this.ID = ID;
    }
}
