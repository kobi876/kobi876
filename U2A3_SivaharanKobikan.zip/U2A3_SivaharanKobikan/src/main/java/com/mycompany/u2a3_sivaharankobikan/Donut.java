/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.u2a3_sivaharankobikan;

/**
 *
 * @author kobikan
 */
public class Donut extends Shape{
    private double lRadius, sRadius;
    private int ID;

    public Donut(double lRadius, double sRadius, int ID) {
        this.lRadius = lRadius;
        this.sRadius = sRadius;
        this.ID = ID;
    }

    public double getArea() {
        return (2 * Math.PI * lRadius) - (2 * Math.PI * sRadius);
    }

    public int getID() {
        return ID;
    }

    public String toString() {
        return ID + " Donut: Larger Radius = " + lRadius + ", Smaller Radius = " + sRadius;
    }
    
     @Override
    public void setID(int ID) {
        this.ID = ID;
    }
}
