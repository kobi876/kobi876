/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.u2a3_sivaharankobikan;

/**
 *
 * @author kobikan
 */
    public abstract class Shape {
    protected double unitPrice;
    protected double[] dimensionList;

    public double[] getDimensionList() {
        return dimensionList;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public abstract double getArea();
    public abstract int getID();
    public abstract void setID(int ID);

}
