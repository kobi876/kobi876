/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.u2a3_sivaharankobikan;

/**
 *
 * @author kobikan
 */
public class Circle extends Shape{
    private double radius;
    private int ID;

    public Circle(double radius, int ID) {
        this.radius = radius;
        this.ID = ID;
    }

    public double getArea() {
        return Math.PI * (radius * radius);
    }

    @Override
    public String toString() {
        return  ID + " Circle: Radius = " + radius ;
    }

    @Override
    public int getID() {
        
        return ID;
    
    }

    @Override
    public void setID(int ID) {
        this.ID = ID;
    }   
}
