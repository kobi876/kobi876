/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.u2a1_sivaharankobikan;

/**
 *
 * @author kobikan
 */
public class Vehicle {
    static double gasPrice, distance;
    private String licensePlate;
    private int passengerNum;
    private double passengerFare, fuelEfficiency;

    public Vehicle(String licensePlate, int passengerNum, double passengerFare, double fuelEfficiency) {
        this.licensePlate = licensePlate;
        this.passengerNum = passengerNum;
        this.passengerFare = passengerFare;
        this.fuelEfficiency = fuelEfficiency;
    }
    
    public double revenue(){
       return passengerNum*passengerFare; 
    }
    
    public double totalCost(){
        return gasPrice*distance;
    }
    
    public double calculateProfit(){
        return totalCost()-revenue();
    }
    
    public static Vehicle compareTo(Vehicle a, Vehicle b){
        if (a.calculateProfit()>b.calculateProfit()){
            return a;
            
        }
        else{
            return b;
        }
    }

    public static void setGasPrice(double gasPrice) {
        Vehicle.gasPrice = gasPrice;
    }

    public static void setDistance(double distance) {
        Vehicle.distance = distance;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public int getPassengerNum() {
        return passengerNum;
    }

    public double getPassengerFare() {
        return passengerFare;
    }

    public double getFuelEfficiency() {
        return fuelEfficiency;
    }
    
    @Override
    public String toString() {
        return "licensePlate= " + licensePlate + "\npassengerNum= " + passengerNum + "\npassengerFare= $" + passengerFare + "\nfuelEfficiency= " + fuelEfficiency + " L/km\ngasPrice= $"+gasPrice+"\n";    
    }
    
}
